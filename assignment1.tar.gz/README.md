Name:			Anthony Rufin
Panther ID:		6227314

Class:			TCN5440
Section:		U01
Semester:		Spring 2025

Assignment:		Programming Assignment 1
Due:			February 13, 2025

Honesty Statement:	I have done this assignment completely on my own. I have not copied it, nor have I given my solution to anyone else. 
			I understand that if I am involved in plagiarism or cheating I will receive the penalty specified in the FIU regulations.
